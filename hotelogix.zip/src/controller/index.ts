import token from "./tokenGenrate";
import getBooking from "./getBooking";
import getUsers from "./getUsers";
import roomDetails from "./getRoomDetails";

export default {
    token,
    getBooking,
    getUsers,
    roomDetails
}