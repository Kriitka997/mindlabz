import wsAuth from "./wsAuth";
import login from "./login";
import signature from "./hotelogixSignature";

export default {
    wsAuth,
    signature,
    login
}
