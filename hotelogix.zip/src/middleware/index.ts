import tokenVer from "./token-verify";

export default {
    tokenVer
}