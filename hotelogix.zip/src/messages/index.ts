import success from "./success-response";
import error from "./error-response";

export default {
    success,
    error
}
