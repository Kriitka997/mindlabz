export default {
    valid: { statusCode: 200, message: "vendor is valid " },
    created: { statusCode: 200, message: "token created successfully.. " },
    details: { statusCode: 200, message: "got room details successfully.. " },
}