export default {

    CounterName: "Morning",

    CounterId: "Nzd4bWhtRVhySzg9",

    ConsumerKey: "13E1DD90BF875A42B4CCED372344411A0A902520",

    ConsumerSecret: "076C70B9A1C4072EAC9091D46A6C502AD9D97DF7",

    url: "https://crs.staygrid.com/ws/web"
}